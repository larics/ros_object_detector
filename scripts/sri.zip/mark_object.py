#!/usr/bin/env python3

import cv2
import numpy as np
import glob
import matplotlib.pyplot as plt
import matplotlib.patches as patches
import pcl
from pcl import pcl_visualization

from geometry_msgs.msg import TransformStamped
import tf2_ros

import trans_to_mat


class Rectangle:
    def __init__(self):


        self.x1 = -1
        self.y1 = -1
        self.x2 = -1
        self.y2 = -1
        self.imhandle = None

        self.limits = None

    def onclick(self, event):
        self.x1 = event.xdata
        self.y1 = event.ydata

    def offclick(self, event):
        self.x2 = event.xdata
        self.y2 = event.ydata
        
        print(self.x1)
        print(self.x2)
        print(self.y1)
        print(self.y2)
        
        x1 = min(self.x1, self.x2)
        x2 = max(self.x1, self.x2)

        y1 = min(self.y1, self.y2)
        y2 = max(self.y1, self.y2)

        rect = patches.Rectangle((x1, y1), abs(x2-x1), abs(y2-y1), linewidth=2, edgecolor='b', facecolor='none')
        self.imhandle.add_patch(rect)
        print("drawn")
        plt.close()


    def filter_pointcloud(self, pc_in):

        tmp = []

        x1 = int(self.x1)
        x2 = int(self.x2)
        y1 = int(self.y1)
        y2 = int(self.y2)

        for x in range(x1, x2):
            for y in range(y1, y2):
                ptemp = pc_in.get_point(x,y)
                if not np.isnan(sum(ptemp)):
                    tmp.append(ptemp)
        
        pc_out = pcl.PointCloud()
        # print(np.median(tmp,0))
        centred = tmp - np.mean(tmp, 0)

        # print(np.median(tmp,0))

        pc_out.from_list(tmp)

        return pc_out



    def filter_and_transform(self, pc_in, mat):

        tmp = []

        x1 = int(self.x1)
        x2 = int(self.x2)
        y1 = int(self.y1)
        y2 = int(self.y2)

        for x in range(x1, x2):
            for y in range(y1, y2):
                ptemp = list(pc_in.get_point(x,y))
                ptemp.append(1.)
                p2 = (np.array(ptemp))
                p_trans = np.dot(mat, p2)

                if not np.isnan(sum(ptemp)):
                    tmp.append(p_trans[0:3])
        
        pc_out = pcl.PointCloud()
        # print(np.median(tmp,0))
        centred = tmp - np.mean(tmp, 0)

        # print(np.median(tmp,0))

        print("limits")
        print(np.min(tmp,0))
        print(np.max(tmp,0))

        self.limits['min'] = np.min(tmp,0)
        self.limits['max'] = np.max(tmp,0)

        
        pc_out.from_list(tmp)

        return pc_out


if __name__ == '__main__':

    trans = TransformStamped()                                              
    trans.transform.translation.x = -0.02779859555256592                    
    trans.transform.translation.y = 0.54458                                 
    trans.transform.translation.z = 0.596741                                
    trans.transform.rotation.x = -0.738788002226365                         
    trans.transform.rotation.y = 0.17212062912091053                       
    trans.transform.rotation.z = -0.15450400355698954                      
    trans.transform.rotation.w = 0.6330049681339486      

    mat = trans_to_mat.msg_to_se3(trans)

    impath = '/home/mars/data/flower_data/imgs/orig/*.jpg'
    # impath = '/home/marsela/libraries/auto-label/*.jpg'
    
    images = [cv2.imread(file) for file in glob.glob(impath)]

    # print(images)

    i = 0
    img = images[i]

    r = Rectangle()

    fig, r.imhandle = plt.subplots()
    r.imhandle.imshow(img)

    cid1 = fig.canvas.mpl_connect('button_press_event', r.onclick)
    cid2 = fig.canvas.mpl_connect('button_release_event', r.offclick)

    plt.show()

    pcdpath = '/home/mars/data/flower_data/pcds/trans/1626273520.910244226.pcd'
    pcdpath = '/home/mars/data/flower_data/pcds/orig/1625835009.146788120.pcd'
    pc = pcl.load(pcdpath)
    
    # labeled_object = r.filter_pointcloud(pc)
    labeled_object = r.filter_and_transform(pc, mat)


    visual = pcl.pcl_visualization.CloudViewing()
    visual.ShowMonochromeCloud(labeled_object)#, b'cloud')
    # visual.ShowGrayCloud(labeled_object, b'cloud')

    v = True
    while v:
        v = not(visual.WasStopped())
